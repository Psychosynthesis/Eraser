export const defaultSettings = {
	status: true
};

export const EXTENSION_NAME = "UTM Eraser";

export const SETTINGS_KEY = "UTMeraserSettings";

export const CANT_FIND_SETTINGS_MSG = "Can't find the UTMeraser settings. Setup new.";
